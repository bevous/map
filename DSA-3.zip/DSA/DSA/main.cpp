#include <string>

#include "avl_tree.h"

int main()
{
	nwacc::avl_tree<std::string> t;

	t.insert("D");
	t.print();
	t.insert("E");
	t.print();
	t.insert("F");
	t.print();
	t.insert("H");
	t.print();
	t.insert("G");
	t.print();
}
