#ifndef TREE_H_
#define TREE_H_

#include <algorithm>
#include <iostream>
#include <string>

namespace nwacc
{
	template<typename T>
	class tree
	{
	public:
		tree() : root { nullptr } {}

		tree(const tree & rhs) : root { nullptr }
		{
			this->root = this->clone(rhs.root);
		}

		tree(tree && rhs) : root { rhs.root }
		{
			rhs.root = nullptr;
		}

		~tree()
		{
			this->empty(this->root);
		}

		void insert(const T & value)
		{
			this->insert(value, this->root);
		}

		void remove(const T & value)
		{
			this->remove(value, this->root);
		}

		bool contains(const T & value) const
		{
			return this->contains(value, this->root);
		}

		bool is_empty() const
		{
			return this->root == nullptr;
		}

		void print(std::ostream & out = std::cout)
		{
			if (this->is_empty())
			{
				out << "Empty Tree" << std::endl;
			} 
			else
			{
				this->print(this->root, out);
			}
		}

	private:

		struct node
		{
			T element;
			node * left;
			node * right;

			node(const T & the_element, node * left_node, node * right_node) :
				element{ the_element }, left{ left_node }, right{ right_node } {}

			node(T && the_element, node * left_node, node * right_node) :
			element { std::move(the_element) }, left { left_node }, right { right_node } {}
		};

		node * root;

		node * clone(node * current) const
		{
			if (current == nullptr)
			{
				return nullptr;
			}
			else
			{
				return new node{ 
					current->element, this->clone(current->left), this->clone(current->right) };
			}
		}

		void print(node * current, std::ostream & out) const
		{
			if (current != nullptr)
			{
				// order is in-order. 
				// this->print(current->left, out);
				// out << current->element << std::endl;
				// this->print(current->right, out);

				// order is post-order
				// this->print(current->left, out);
				// this->print(current->right, out);
				// out << current->element << std::endl;

				// order is pre-order
				out << current->element << std::endl;
				this->print(current->left, out);
				this->print(current->right, out);
			}
		}

		void empty(node * & current)
		{
			if (current != nullptr)
			{
				this->empty(current->left);
				this->empty(current->right);
				delete current;
			}
			current = nullptr;
		}

		bool contains(const T & value, node * current) const
		{
			while (current != nullptr)
			{
				if (value < current->element)
				{
					current = current->left;
				}
				else if (current->element < value)
				{
					current = current->right;
				}
				else
				{
					return true;
				}
			}
			return false;
		}

		void insert(const T & value, node * & current)
		{
			if (current == nullptr)
			{
				current = new node{ value, nullptr, nullptr };
			}
			else if (value < current->element)
			{
				this->insert(value, current->left);
			}
			else if (current->element < value)
			{
				this->insert(value, current->right);
			}
			else
			{
				// we found a duplicate. do_nothing();
				return;
			}
		}

		void remove(const T & value, node * & current)
		{
			if (current == nullptr)
			{
				// we did not find the item to remove, we found nullptr. 
				return;
			} // else, we are still looking, do_nothing();

			if (value < current->element)
			{
				this->remove(value, current->left);
			}
			else if (current->element < value)
			{
				this->remove(value, current->right);
			}
			else if (current->left != nullptr && current->right != nullptr)
			{
				// we have two children!
				current->element = this->find_min(current->right)->element;
				this->remove(current->element, current->right);
			}
			else
			{
				// we have either one child or no children :(
				node * old_node = current;
				current = (current->left != nullptr) ? current->left : current->right;
				delete old_node;
			}
		}

		node * find_min(node * current) const
		{
			if (current == nullptr)
			{
				return nullptr;
			} // else, current is not null, do_nothing();

			if (current->left == nullptr)
			{
				return current;
			} // else, we still have more children do_nothing();

			return this->find_min(current->left);
		}

	};
}

#endif
