#ifndef AVL_TREE_H_
#define AVL_TREE_H_

#include <algorithm>
#include <iostream>
#include <stdexcept>

namespace nwacc
{
	template<typename T>
	class avl_tree
	{
	public:

		avl_tree() : root { nullptr } {}

		avl_tree(const avl_tree & rhs) : root { nullptr }
		{
			this->root = this->clone(rhs.root);
		}

		avl_tree(avl_tree && rhs) : root { rhs.root }
		{
			rhs.root = nullptr;
		}

		~avl_tree()
		{
			this->empty();
		}

		avl_tree & operator=(const avl_tree & rhs)
		{
			auto copy = rhs;
			std::swap(*this, copy);
			return *this;
		}

		avl_tree & operator=(avl_tree && rhs)
		{
			std::swap(this->root, rhs.root);
			return *this;
		}

		bool is_empty() const
		{
			return this->root == nullptr;
		}

		void empty()
		{
			this->empty(this->root);
		}

		bool contains(const T & value) const
		{
			return this->contains(value, this->root);
		}

		const T & find_min() const
		{
			if (this->is_empty())
			{
				throw new std::range_error("Tree is empty");
			}
			else
			{
				return this->find_min(this->root)->element;
			}
		}

		const T & find_max() const
		{
			if (this->is_empty())
			{
				throw new std::range_error("Tree is empty");
			}
			else
			{
				return this->find_max(this->root)->element;
			}
		}

		void insert(const T & value)
		{
			this->insert(value, this->root);
		}

		void insert(T && value)
		{
			this->insert(std::move(value), this->root);
		}

		void remove(const T & value)
		{
			this->remove(value, this->root);
		}

		void print(std::ostream & out = std::cout)
		{
			this->indent = -4;
			this->print(out, this->root);
			out << std::endl;
		}

	private:
		// for printing. 
		int indent = 0;

		struct node
		{
			T element;
			node * left;
			node * right;
			int height;

			node (const T & the_element, node * the_left, node * the_right, int the_height = 0)
				: element { the_element }, left { the_left }, 
				  right { the_right }, height { the_height } {}

			node (T && the_element, node * the_left, node * the_right, int the_height = 0)
				: element{ std::move(the_element) }, left{ the_left },
				  right{ the_right }, height{ the_height } {}
		};

		node * root;

		void print(std::ostream & out, node * parent)
		{
			if (parent == nullptr)
			{
				return;
			} // else, we still have data do_nothing();

			this->indent += 4;
			this->print(out, parent->left);
			for (auto counter = 0; counter < this->indent; counter++)
			{
				out << ' ';
			}

			out << parent->element << '|' << parent->height << std::endl;;
			this->print(out, parent->right);
			this->indent -= 4;
		}

		void empty(node * & current)
		{
			if (current != nullptr)
			{
				this->empty(current->left);
				this->empty(current->right);
				delete current;
			} // else, current is null, do_nothing();

			current = nullptr;
		}

		node * clone(node * current) const
		{
			if (current == nullptr)
				return nullptr;
			else
				return new node{ current->element, clone(current->left), clone(current->right), current->height };
		}

		void insert(const T & value, node * & current)
		{
			if (current == nullptr)
			{
				current = new node{ value, nullptr, nullptr };
			}
			else if (value < current->element)
			{
				this->insert(value, current->left);
			}
			else if (current->element < value)
			{
				this->insert(value, current->right);
			} // else, duplicate found, do_nothing();

			this->balance(current);
		}

		void insert(T && value, node * & current)
		{
			if (current == nullptr)
			{
				current = new node{ std::move(value), nullptr, nullptr };
			}
			else if (value < current->element)
			{
				this->insert(std::move(value), current->left);
			}
			else if (current->element < value)
			{
				this->insert(std::move(value), current->right);
			} // else, duplicate found, do_nothing();

			this->balance(current);
		}

		void remove(const T & value, node * & current)
		{
			if (current == nullptr)
			{
				// we did not find the item to remove. 
				return; 
			} // else, we found the item do_nothing();

			if (value < current->element)
			{
				this->remove(value, current->left);
			}
			else if (current->element < value)
			{
				this->remove(value, current->right);
			}
			else if (current->left != nullptr && current->right != nullptr)
			{
				// here we have two children
				current->element = this->find_min(current->right)->element;
				this->remove(current->element, current->right);
			}
			else
			{
				// here we have no children :( or one child. 
				node * old_node = current;
				current = (current->left != nullptr) ? current->left : current->right;
				delete old_node;
			}

			this->balance(current);
		}

		bool contains(const T & value, node * current) const
		{
			if (current == nullptr)
			{
				return false; // Does not exist in the tree :(
			} 
			else if (value < current->element)
			{
				return this->contains(value, current->left);
			} 
			else if (current->element < value)
			{
				return this->contains(value, current->right);
			}
			else
			{
				return true; // We found it!
			}
		}

		node * find_min(node * current) const
		{
			if (current == nullptr)
			{
				return nullptr;
			} // else, we are at the end, do_nothing();

			if (current->left == nullptr)
			{
				return current;
			} // else, we have found the smallest, do_nothing();

			return this->find_min(current->left);
		}

		node * find_max(node * current) const
		{
			if (current != nullptr)
			{
				while (current->right != nullptr)
				{
					current = current->right;
				}
			}
			return current;
		}

		int height(node * current) const
		{
			return current == nullptr ? -1 : current->height;
		}

		/**
		 * Rotate binary tree node with left child. This is a 
		 * single rotation. 
		 */
		void rotate_with_left_child(node * & current)
		{
			auto * temp = current->left;
			current->left = temp->right; // current->left->right;
			temp->right = current;

			current->height = std::max(this->height(current->left), this->height(current->right)) + 1;
			temp->height = std::max(this->height(temp->left), current->height) + 1;
			
			current = temp;
		}

		void rotate_with_right_child(node * & current)
		{
			auto * temp = current->right;
			current->right = temp->left;
			temp->left = current;

			current->height = std::max(this->height(current->left), this->height(current->right)) + 1;
			temp->height = std::max(this->height(temp->right), current->height) + 1;

			current = temp;
		}

		/**
		 * Double rotate binary tree node - first rotate the left child
		 * with its right child; then with the new left child. 
		 */
		void double_rotate_with_left_child(node * & current)
		{
			this->rotate_with_right_child(current->left);
			this->rotate_with_left_child(current);
		}

		void double_rotate_with_right_child(node * & current)
		{
			this->rotate_with_left_child(current->right);
			this->rotate_with_right_child(current);
		}

		void balance(node * & current)
		{
			if (current == nullptr)
			{
				return;
			} // else, we have a valid node do_nothing();

			if (this->height(current->left) - 
				this->height(current->right) > 1)
			{
				// left side has a greater height
				if (this->height(current->left->left) >=
					this->height(current->left->right))
				{
					this->rotate_with_left_child(current);
				}
				else
				{
					this->double_rotate_with_left_child(current);
				}
			}
			else if (this->height(current->right) - 
				     this->height(current->left) > 1) 
			{
				// right side has a greater height
				if (this->height(current->right->right) >= 
					this->height(current->right->left))
				{
					this->rotate_with_right_child(current);
				}
				else
				{
					this->double_rotate_with_right_child(current);
				}
			} // else, the nodes are balanced within 1, do_nothing();

			current->height = std::max(
				this->height(current->left),
				this->height(current->right)) + 1;
		}
	};
}

#endif // AVL_TREE_H_